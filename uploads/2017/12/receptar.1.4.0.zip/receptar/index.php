<?php
/**
 * General index template
 *
 * @package    Receptar
 * @copyright  2015 WebMan - Oliver Juhas
 *
 * @since    1.0
 * @version  1.3
 */



get_header();

	get_template_part( 'template-parts/loop', 'index' );

get_footer();
